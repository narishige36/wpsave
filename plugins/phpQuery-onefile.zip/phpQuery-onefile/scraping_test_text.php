<?php
/*
  Plugin Name: scraping_test
  Plugin URI:
  Description: 株価をスクレイプする
  Version: 1.0.0
  Author: Shogo Narishige
  Author URI: 
  License: GPLv2
 */
echo "test";
